package com.xskj.LicenseTips;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LicenseTipsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LicenseTipsApplication.class, args);
	}

}
